# WEEK 09 – TUTORIAL 7

students = {
    "Anna": {"IT": 78, "Science": 72},
    "John": {"IT": 65, "Science": 60},
    "Peter": {"IT": 82, "Science": 70},
    "Lucy": {"IT": 91, "Science": 85}
}

def display_students(data):
    print("\nStudents and marks:")
    for name, marks in data.items():
        print(name, ":", marks)

def total_marks(name):
    if name in students:
        return sum(students[name].values())
    else:
        return None

def calculate_grade(total):
    if total >= 160:
        return "A"
    elif total >= 120:
        return "B"
    elif total >= 80:
        return "C"
    else:
        return "Fail"

def search_student():
    name = input("Enter student name: ")
    if name in students:
        total = total_marks(name)
        grade = calculate_grade(total)
        print("Student:", name)
        print("Marks:", students[name])
        print("Total:", total)
        print("Grade:", grade)
    else:
        print("Student not found.")

def add_student():
    name = input("Enter student name: ")
    it = int(input("IT mark: "))
    science = int(input("Science mark: "))
    students[name] = {"IT": it, "Science": science}
    print("Student added.")

# MAIN
print("WEEK 09 – TUTORIAL 7")

display_students(students)
add_student()
search_student()
