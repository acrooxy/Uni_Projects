# Week 09 Tutorial 4
# Sum all digits of a number using a function

def sum_digits(number):
    # Convert the input number to a positive integer
    number = abs(int(number))
    # Create a variable to store the running total
    total = 0
    # Repeat until the number becomes 0
    while number > 0:
        # Get the last digit of the number
        digit = number % 10
        # Add the digit to the total
        total = total + digit
        # Remove the last digit from the number
        number = number // 10
    # Return the final total
    return total

# Ask the user to type a whole number
user_number = int(input("Type a number: "))

# Call the function and store the returned result
result = sum_digits(user_number)

# Print the final answer
print("Sum of digits =", result)
