
# WEEK 09 – TUTORIAL 5
# Calculate total, average and maximum of numbers in a list
# Using functions


# Function to calculate the total (sum) of all numbers in a list
def get_total(numbers):
    total = 0                          # Create a variable to store the running total
    for n in numbers:                  # Loop through each number in the list
        total = total + n              # Add the current number to total
    return total                       # Return the final total


# Function to calculate the average of numbers in a list
def get_average(numbers):
    total = get_total(numbers)         # Get the total using the get_total function
    count = len(numbers)               # Count how many numbers are in the list
    average = total / count            # Divide total by count to get average
    return average                     # Return the average result


# Function to find the maximum (largest) number in a list
def get_maximum(numbers):
    maximum = numbers[0]               # Start by assuming the first number is the maximum
    for n in numbers:                  # Loop through each number
        if n > maximum:                # If current number is bigger than maximum
            maximum = n                # Update maximum
    return maximum                     # Return the final maximum value


# Ask the user to enter at least 4 numbers
numbers_list = []                      # Create an empty list to store numbers
how_many = 4                           # Minimum amount of numbers required

# Tell the user what to do
print("Enter 4 numbers (minimum).")

# Loop exactly 4 times to get 4 numbers from the user
for i in range(how_many):
    num = float(input("Enter number " + str(i + 1) + ": "))   # Read a number from user
    numbers_list.append(num)                                   # Add the number into the list

# Calculate total using the function
total_result = get_total(numbers_list)

# Calculate average using the function
average_result = get_average(numbers_list)

# Calculate maximum using the function
maximum_result = get_maximum(numbers_list)

# Print the results to the screen
print("Numbers:", numbers_list)
print("Total:", total_result)
print("Average:", average_result)
print("Maximum:", maximum_result)
