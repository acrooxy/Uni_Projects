
# WEEK 09 – TUTORIAL 9
# Menu driven program


# Function to add two numbers
def add_numbers():
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))
    print("Result:", a + b)


# Function to subtract two numbers
def subtract_numbers():
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))
    print("Result:", a - b)


# Function to multiply two numbers
def multiply_numbers():
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))
    print("Result:", a * b)


# Function to divide two numbers
def divide_numbers():
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))
    if b == 0:
        print("Cannot divide by zero")
    else:
        print("Result:", a / b)


# Main menu loop
while True:
    print("\n=== SIMPLE CALCULATOR MENU ===")
    print("1. Add")
    print("2. Subtract")
    print("3. Multiply")
    print("4. Divide")
    print("5. Exit")

    choice = input("Choose an option (1-5): ")

    if choice == "1":
        add_numbers()
    elif choice == "2":
        subtract_numbers()
    elif choice == "3":
        multiply_numbers()
    elif choice == "4":
        divide_numbers()
    elif choice == "5":
        print("Program finished.")
        break
    else:
        print("Invalid option, try again.")
