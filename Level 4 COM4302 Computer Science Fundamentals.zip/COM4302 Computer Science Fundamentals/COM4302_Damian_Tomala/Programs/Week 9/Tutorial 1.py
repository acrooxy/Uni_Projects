
# WEEK 09 – TUTORIAL 1

# Program demonstrating basic mathematical operations
# using user-defined functions


# Function to add two numbers
def add(a, b):
    # Return the sum of a and b
    return a + b


# Function to subtract second number from the first
def sub(a, b):
    # Return the result of subtraction
    return a - b


# Function to multiply two numbers
def mul(a, b):
    # Return the product of a and b
    return a * b


# Function to divide two numbers
def div(a, b):
    # Check if divisor is zero to avoid error
    if b == 0:
        return "Cannot divide by zero"
    # Return the division result
    return a / b


# Ask the user to enter the first number
num1 = float(input("Enter the first number: "))

# Ask the user to enter the second number
num2 = float(input("Enter the second number: "))

# Call the add function and display the result
print("Addition result:", add(num1, num2))

# Call the subtract function and display the result
print("Subtraction result:", sub(num1, num2))

# Call the multiply function and display the result
print("Multiplication result:", mul(num1, num2))

# Call the division function and display the result
print("Division result:", div(num1, num2))
