
# WEEK 09 – TUTORIAL 11
# Number guessing game using while loop


import random   # Import module for random numbers

# Generate a random number between 1 and 10
secret_number = random.randint(1, 10)

# Variable to store user's guess
guess = 0

# Loop until the user guesses the correct number
while guess != secret_number:
    guess = int(input("Guess a number between 1 and 10: "))

    if guess < secret_number:
        print("Too low! Try again.")
    elif guess > secret_number:
        print("Too high! Try again.")
    else:
        print("Correct! You guessed the number.")
