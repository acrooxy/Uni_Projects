# WEEK 09 – TUTORIAL 10
# Menu program using students dictionary

students = {
    "Anna": {"IT": 78, "Science": 72},
    "John": {"IT": 65, "Science": 60},
    "Peter": {"IT": 82, "Science": 70},
    "Lucy": {"IT": 91, "Science": 85}
}

def display_students():
    print("\nAll students and marks:")
    for name, marks in students.items():
        print(name, ":", marks)

def calculate_grade(total):
    if total >= 160:
        return "A"
    elif total >= 120:
        return "B"
    elif total >= 80:
        return "C"
    else:
        return "Fail"

def show_grades():
    print("\nStudent grades:")
    for name, marks in students.items():
        total = sum(marks.values())
        grade = calculate_grade(total)
        print(name, "- Total:", total, "Grade:", grade)

def search_student():
    name = input("Enter student name: ")
    if name in students:
        total = sum(students[name].values())
        grade = calculate_grade(total)
        print("Student:", name)
        print("Marks:", students[name])
        print("Total:", total)
        print("Grade:", grade)
    else:
        print("Student not found.")

# MENU
while True:
    print("\n=== STUDENT MENU ===")
    print("1. Display all students")
    print("2. Display grades")
    print("3. Search student")
    print("4. Exit")

    choice = input("Choose option (1-4): ")

    if choice == "1":
        display_students()
    elif choice == "2":
        show_grades()
    elif choice == "3":
        search_student()
    elif choice == "4":
        print("Program finished.")
        break
    else:
        print("Invalid option. Try again.")
