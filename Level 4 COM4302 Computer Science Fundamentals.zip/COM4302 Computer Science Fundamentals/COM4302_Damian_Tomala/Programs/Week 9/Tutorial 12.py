
# Week 9 Tutorial 12 - Modify WEEK 06 – TUTORIAL 8
# 10-question quiz (improved)


def read_yes_no(prompt):
    while True:
        ans = input(prompt).strip().lower()
        if ans == "yes" or ans == "no":
            return ans
        print("Type yes or no.")

def read_choice(prompt, choices):
    while True:
        ans = input(prompt).strip().lower()
        if ans in choices:
            return ans
        print("Choose:", ", ".join(choices))

def ask_question(number, question, options, correct):
    print("\nQuestion", number)
    print(question)
    print("a.", options["a"])
    print("b.", options["b"])
    print("c.", options["c"])
    print("d.", options["d"])

    answer = read_choice("Your answer (a/b/c/d): ", ["a", "b", "c", "d"])

    if answer == correct:
        print("Correct.")
        return 1
    else:
        print("Wrong. Correct answer:", correct)
        return 0

def run_quiz():
    questions = [
        ("What does CPU stand for?",
         {"a": "Central Processing Unit", "b": "Computer Power Unit", "c": "Central Program Utility", "d": "Core Processing User"},
         "a"),

        ("Which one is an operating system?",
         {"a": "Python", "b": "Windows", "c": "HTML", "d": "SQL"},
         "b"),

        ("What does RAM stand for?",
         {"a": "Random Access Memory", "b": "Read Access Memory", "c": "Rapid Action Module", "d": "Run All Memory"},
         "a"),

        ("Which device connects a home network to the internet?",
         {"a": "Monitor", "b": "Router", "c": "Keyboard", "d": "Printer"},
         "b"),

        ("Which one is a strong password example?",
         {"a": "password123", "b": "Damian1", "c": "QwErTy", "d": "V9r!k2@pL#7"},
         "d"),

        ("What is phishing?",
         {"a": "A type of firewall", "b": "A scam to steal information", "c": "A programming language", "d": "A hard drive format"},
         "b"),

        ("Which protocol is used for secure web browsing?",
         {"a": "HTTP", "b": "FTP", "c": "HTTPS", "d": "SMTP"},
         "c"),

        ("What does a VPN help with?",
         {"a": "Makes CPU faster", "b": "Protects privacy by encrypting traffic", "c": "Deletes viruses automatically", "d": "Increases screen resolution"},
         "b"),

        ("What is malware?",
         {"a": "Any software", "b": "A computer game", "c": "Malicious software", "d": "A browser extension"},
         "c"),

        ("Which one is a database?",
         {"a": "MySQL", "b": "PowerPoint", "c": "Paint", "d": "Calculator"},
         "a"),
    ]

    score = 0
    for i, item in enumerate(questions, start=1):
        question, options, correct = item
        score += ask_question(i, question, options, correct)

    print("\nQuiz finished.")
    print("Your score:", score, "/ 10")

def main():
    print("WEEK 06 – TUTORIAL 8")
    print("10-question quiz\n")

    while True:
        run_quiz()
        again = read_yes_no("Will you run the program again (yes/no)? ")
        if again == "no":
            print("Program finished.")
            break

if __name__ == "__main__":
    main()

