# Week 09 Tutorial 6  # Program title and tutorial number
# Create a list of 10 fruits and use 3 functions as required  # Purpose of the program

fruits = ["apple", "banana", "orange", "grape", "mango", "pear", "peach", "plum", "kiwi", "melon"]  # Create a list with 10 fruits


def print_fruits_list(items):  # Define a function to print the full list
    print("Full fruits list:")  # Print a label before the list
    for fruit in items:  # Loop through each fruit in the list
        print(fruit)  # Print one fruit per line


def print_character_counts(items):  # Define a function to count characters for each fruit
    print("Character count for each fruit:")  # Print a label before results
    for fruit in items:  # Loop through each fruit
        count = len(fruit)  # Count how many characters are in the fruit name
        print(fruit + " has " + str(count) + " characters")  # Print fruit name and its character count


def add_new_fruit(items):  # Define a function to add a new fruit to the list
    new_fruit = input("Type a new fruit to add: ").strip()  # Ask user to enter a fruit name
    items.append(new_fruit)  # Add the new fruit into the list
    print(new_fruit + " was added to the list.")  # Confirm the fruit was added


print_fruits_list(fruits)  # Call function to display the full list first
print_character_counts(fruits)  # Call function to display character counts
add_new_fruit(fruits)  # Call function to add a new fruit
print_fruits_list(fruits)  # Print the list again to show the new fruit was added
