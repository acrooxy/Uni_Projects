
# WEEK 09 – TUTORIAL 3
# Drawing shapes using functions and loops



# Function to draw a triangle made of stars

def draw_triangle(size):
    # Loop through rows from 1 to given size
    for i in range(1, size + 1):
        # Print stars in increasing order
        print("*" * i)



# Function to draw a rectangle using stars

def draw_rectangle(width, height):
    # Loop through number of rows
    for i in range(height):
        # Print a row of stars
        print("*" * width)


# MAIN PROGRAM


print("WEEK 09 – TUTORIAL 3")
print("Drawing shapes using functions\n")

# Ask user for triangle size
triangle_size = int(input("Enter size of triangle: "))

# Call function to draw triangle
draw_triangle(triangle_size)

print()  # empty line for spacing

# Ask user for rectangle size
rect_width = int(input("Enter rectangle width: "))
rect_height = int(input("Enter rectangle height: "))

# Call function to draw rectangle
draw_rectangle(rect_width, rect_height)
