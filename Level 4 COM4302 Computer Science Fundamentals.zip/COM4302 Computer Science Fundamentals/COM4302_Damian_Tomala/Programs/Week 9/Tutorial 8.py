total = 0
# Program additionaly Handles wrong input
while True:
    try:
        number = int(input("Type your number: "))
        total += number
        print("Your total:", total)
    except ValueError:
        print("Please enter a valid number.")
        continue

    answer = input("Will you run the program again (yes/no)? ").strip().lower()
    if answer != "yes":
        print("Program finished.")
        break
