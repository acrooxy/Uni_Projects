
# WEEK 09 – TUTORIAL 2
# Working with LOOPS (for / while)


# This program demonstrates how to use loops in Python
# It performs several tasks using for and while loops



# TASK 1 – Print numbers from 1 to 10


print("Numbers from 1 to 10:")

# Loop from 1 to 10
for i in range(1, 11):
    print(i)



# TASK 2 – Print numbers from 10 down to 1


print("\nNumbers from 10 to 1:")

# Loop from 10 down to 1
for i in range(10, 0, -1):
    print(i)



# TASK 3 – Calculate the sum of numbers from 1 to 10


total = 0  # Variable to store the sum

for i in range(1, 11):
    total = total + i  # Add current number to total

print("\nSum of numbers from 1 to 10:", total)



# TASK 4 – Print even numbers from 1 to 20


print("\nEven numbers from 1 to 20:")

for i in range(1, 21):
    if i % 2 == 0:  # Check if number is even
        print(i)



# TASK 5 – Simple multiplication table


number = int(input("\nEnter a number for multiplication table: "))

for i in range(1, 11):
    print(number, "x", i, "=", number * i)


