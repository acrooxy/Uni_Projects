
# TUTORIAL 3 – LIST OPERATIONS


# Initial list
words = ['jam', 'argue', 'elf', 'brown', 'dice', 'dingo']


# TASK A – Add word "poster" to the end

print("TASK A – Add 'poster' to the list")
words.append("poster")
print(words)


# TASK B – Add word "bin" between 'elf' and 'brown'

print("\nTASK B – Insert 'bin' between 'elf' and 'brown'")
words.insert(3, "bin")
print(words)


# TASK C – Reverse the list

print("\nTASK C – Reverse the list")
words.reverse()
print(words)


# TASK D – Remove the word 'dice'

print("\nTASK D – Remove 'dice'")
if "dice" in words:
    words.remove("dice")
print(words)


# TASK E – Add list ['table', 'brave', 'cat']

print("\nTASK E – Add another list")
words.extend(['table', 'brave', 'cat'])
print(words)


# TASK F – Create new list with 2nd, 3rd and 4th items

print("\nTASK F – New list with selected elements")
newWords = words[1:4]
print(newWords)


# TASK G – Print list in UPPER CASE

print("\nTASK G – Upper case")
for word in words:
    print(word.upper())


# TASK H – Print list in Title Case

print("\nTASK H – Title case")
for word in words:
    print(word.title())


# TASK I – Print last three items

print("\nTASK I – Last three items")
print(words[-3:])