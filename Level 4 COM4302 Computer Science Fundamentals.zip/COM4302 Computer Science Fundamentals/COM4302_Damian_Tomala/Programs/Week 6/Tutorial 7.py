
# TUTORIAL 7 – RANDOM ITEM FROM LIST


import random

# List of fruits
fruits = ["apple", "banana", "orange", "grape", "pear", "mango", "kiwi"]

print("List of fruits:")
print(fruits)

# Generate a random index
random_index = random.randint(0, len(fruits) - 1)

# Display the randomly selected fruit
print("\nRandomly selected fruit:")
print(fruits[random_index])
