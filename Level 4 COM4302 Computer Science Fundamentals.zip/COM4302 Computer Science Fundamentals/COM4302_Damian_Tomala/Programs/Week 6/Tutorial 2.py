
# TUTORIAL 2 – LOOPS AND OUTPUT FORMATTING

# This program contains four tasks:
# 1. Display numbers 1–6 with their powers
# 2. Display numbers 1–50 in rows
# 3. Display number blocks (0–3, 10–13, etc.)
# 4. Display multiplication table



def tutorial2_a():
    print("\nTASK 1 – Numbers and their powers\n")
    for number in range(1, 7):
        square = number ** 2
        cube = number ** 3
        power4 = number ** 4
        print(number, "=", number, square, cube, power4)


def tutorial2_b():
    print("\nTASK 2 – Numbers from 1 to 50\n")
    start = 1
    for _ in range(5):
        for num in range(start, start + 10):
            print(num, end=" ")
        print()
        start += 10


def tutorial2_c():
    print("\nTASK 3 – Number blocks (0–3, 10–13, etc.)\n")
    for tens in range(0, 101, 10):
        for num in range(tens, tens + 4):
            print(num, end=" ")
        print()


def tutorial2_d():
    print("\nTASK 4 – Multiplication table\n")
    for i in range(1, 11):
        for j in range(1, 11):
            print(f"{i} x {j} = {i * j}", end="   ")
        print()
        print("-" * 60)



# MAIN MENU

while True:
    print("\n==============================")
    print("        TUTORIAL 2 MENU       ")
    print("==============================")
    print("1. Display numbers 1–6 with their powers")
    print("2. Display numbers 1–50 in rows")
    print("3. Display number blocks (0–3, 10–13, etc.)")
    print("4. Display multiplication table")
    print("5. Exit")
    print("==============================")

    choice = input("Choose an option: ")

    if choice == "1":
        tutorial2_a()
    elif choice == "2":
        tutorial2_b()
    elif choice == "3":
        tutorial2_c()
    elif choice == "4":
        tutorial2_d()
    elif choice == "5":
        print("Program finished.")
        break
    else:
        print("Invalid option. Please choose 1–5.")