
# TUTORIAL 8 – QUIZ PROGRAM


# List of questions and answers
questions = [
    ("What is the capital of the UK?", "london"),
    ("What is 5 + 5?", "10"),
    ("What colour is the sky on a clear day?", "blue"),
    ("How many days are in a week?", "7"),
    ("What is the opposite of hot?", "cold"),
    ("What is 10 x 2?", "20"),
    ("What planet do we live on?", "earth"),
    ("What is the first letter of the alphabet?", "a"),
    ("How many hours are in a day?", "24"),
    ("What colour are bananas?", "yellow")
]

score = 0

print("=== QUIZ TIME ===")
print("Answer the following questions:\n")

for question, correct_answer in questions:
    user_answer = input(question + " ").lower()
    if user_answer == correct_answer:
        print("Correct!\n")
        score += 1
    else:
        print("Wrong! Correct answer:", correct_answer, "\n")

print("Quiz finished!")
print("Your score:", score, "out of", len(questions))
