
# TUTORIAL 5  COUNT ITEMS IN A LIST


colours = ["red", "green", "red", "blue", "yellow", "pink", "blue", "green", "blue", "white"]

print("COLOURS LIST:")
print(colours)

user_item = input("\nType a colour to count: ").strip().lower()

count = 0
for colour in colours:
    if colour.lower() == user_item:
        count += 1

print("\nRESULT:")
print("The colour", user_item, "appears", count, "time(s) in the list.")