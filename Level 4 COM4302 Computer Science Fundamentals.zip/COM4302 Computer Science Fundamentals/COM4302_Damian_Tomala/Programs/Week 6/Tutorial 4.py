
# TUTORIAL 4 – LIST OPERATIONS (NUMBERS)


# Initial list
nums = [3, 7, 19, 2, 8, 3, 9, 1, 6]


# TASK A – Add number 4 at the end of the list

print("TASK A – Add number 4 at the end")
nums.append(4)
print(nums)


# TASK B – Insert 23 between 2 and 8

print("\nTASK B – Insert 23 between 2 and 8")
index = nums.index(2) + 1
nums.insert(index, 23)
print(nums)


# TASK C – Print 5th to 7th elements

print("\nTASK C – Print 5th to 7th elements")
print(nums[4:7])


# TASK D – Add list [3, 6, 9, 12]

print("\nTASK D – Add another list")
nums.extend([3, 6, 9, 12])
print(nums)


# TASK E – Reverse the list

print("\nTASK E – Reverse the list")
nums.reverse()
print(nums)


# TASK F – Delete the 4th element

print("\nTASK F – Delete the 4th element")
del nums[3]
print(nums)


# TASK G – Sort the list in descending order

print("\nTASK G – Sort list in descending order")
nums.sort(reverse=True)
print(nums)


# TASK H – Print all odd numbers

print("\nTASK H – Print odd numbers")
for num in nums:
    if num % 2 != 0:
        print(num)


# TASK I – Sum all numbers in the list

print("\nTASK I – Sum of all numbers")
print(sum(nums))