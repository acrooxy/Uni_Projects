# Tutorial 1 – All tasks in one program

def task_a():
    text = input("Enter a word: ")
    vowels = "aeiouAEIOU"
    for char in text:
        if char in vowels:
            print(char, "is a vowel")
        else:
            print(char, "is not a vowel")


def task_b():
    total = 0
    for i in range(2, 21, 2):
        total += i
    print("Sum of even numbers from 2 to 20:", total)


def task_c():
    choice = ""
    while choice != "5":
        print("\n1. Add")
        print("2. Search")
        print("3. Update")
        print("4. Delete")
        print("5. Quit")
        choice = input("Choose option: ")

        if choice == "1":
            print("Add selected")
        elif choice == "2":
            print("Search selected")
        elif choice == "3":
            print("Update selected")
        elif choice == "4":
            print("Delete selected")
        elif choice == "5":
            print("Returning to main menu")
        else:
            print("Invalid option")


def task_d():
    num = int(input("Enter a number: "))
    if num < 2:
        print("Not a prime number")
        return
    for i in range(2, num):
        if num % i == 0:
            print("Not a prime number")
            return
    print("Prime number")


def task_e():
    limit = int(input("Enter limit: "))
    for num in range(2, limit + 1):
        prime = True
        for i in range(2, num):
            if num % i == 0:
                prime = False
                break
        if prime:
            print(num)


def task_f():
    number = int(input("Enter number for multiplication table: "))
    for i in range(1, 11):
        print(number, "x", i, "=", number * i)


# MAIN MENU – START POINT
while True:
    print("\n===== TUTORIAL 1 MENU =====")
    print("1. Check vowels")
    print("2. Sum of even numbers")
    print("3. Menu program")
    print("4. Check prime number")
    print("5. List prime numbers")
    print("6. Multiplication table")
    print("7. Exit")

    choice = input("Select an option: ")

    if choice == "1":
        task_a()
    elif choice == "2":
        task_b()
    elif choice == "3":
        task_c()
    elif choice == "4":
        task_d()
    elif choice == "5":
        task_e()
    elif choice == "6":
        task_f()
    elif choice == "7":
        print("Program ended.")
        break
    else:
        print("Invalid choice. Try again.")