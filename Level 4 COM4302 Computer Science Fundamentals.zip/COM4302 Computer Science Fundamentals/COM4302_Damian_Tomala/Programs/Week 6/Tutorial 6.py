
# TUTORIAL 6 – MENU PROGRAM WITH LIST


# Initial list
items = ["apple", "banana", "orange"]

while True:
    print("\n===== TUTORIAL 6 MENU =====")
    print("1. Display items")
    print("2. Add item")
    print("3. Delete item")
    print("4. Exit")
    print("===========================")

    choice = input("Choose an option: ")

    # OPTION 1 – Display items
    if choice == "1":
        print("\nCurrent items:")
        for item in items:
            print("-", item)

    # OPTION 2 – Add item
    elif choice == "2":
        new_item = input("Enter item to add: ")
        items.append(new_item)
        print("Item added.")

    # OPTION 3 – Delete item
    elif choice == "3":
        item_to_remove = input("Enter item to delete: ")
        if item_to_remove in items:
            items.remove(item_to_remove)
            print("Item removed.")
        else:
            print("Item not found.")

    # OPTION 4 – Exit program
    elif choice == "4":
        print("Program ended.")
        break

    else:
        print("Invalid option. Please choose 1–4.")
