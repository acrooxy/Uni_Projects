# Week 5 Tutorial 3

while True:
    print("\nChoose a task:")
    print("a. Student grade calculator")
    print("b. Word length classifier")
    print("c. Menu selection program - Task 3")
    print("d. Hourly rate by profession")
    print("e. Yearly tax and net salary calculator")
    print("q. Quit")

    task = input("Type a letter a b c d e or q: ").lower()

    if task == "q":
        print("Program ended")
        break

    if task == "a":
        print("You selected task 3a")

        mark = int(input("Enter student mark: "))

        if mark > 74:
            print("Distinction")
        elif mark >= 60:
            print("Merit")
        elif mark >= 40:
            print("Pass")
        elif mark >= 0:
            print("Fail")
        else:
            print("Invalid mark")

    elif task == "b":
        print("You selected task 3b")

        text = input("Enter a word: ")
        length = len(text)

        if 1 <= length <= 3:
            print("too short word")
        elif 4 <= length <= 8:
            print("small word")
        elif 9 <= length <= 12:
            print("big word")
        else:
            print("too big word")

    elif task == "c":
        print("You selected task 3c")

        print("1. Add")
        print("2. Search")
        print("3. Update")
        print("4. Delete")

        choice = int(input("Type a number between 1 and 4: "))

        if choice == 1:
            print("Added")
        elif choice == 2:
            print("Searched")
        elif choice == 3:
            print("Updated")
        elif choice == 4:
            print("Deleted")
        else:
            print("Invalid option")

    elif task == "d":
        print("You selected task 3d")

        profession = input("Enter profession teacher doctor lawyer driver: ").lower()

        if profession == "teacher":
            print("Hourly rate is £25")
        elif profession == "doctor":
            print("Hourly rate is £60")
        elif profession == "lawyer":
            print("Hourly rate is £200")
        elif profession == "driver":
            print("Hourly rate is £15")
        else:
            print("Unknown profession")

    elif task == "e":
        print("You selected task 3e")

        salary = float(input("Enter yearly gross salary: "))

        if salary <= 12570:
            tax = 0
        elif salary <= 50270:
            tax = (salary - 12570) * 0.20
        elif salary <= 125140:
            tax = (50270 - 12570) * 0.20 + (salary - 50270) * 0.40
        else:
            tax = (50270 - 12570) * 0.20 + (125140 - 50270) * 0.40 + (salary - 125140) * 0.45

        net_salary = salary - tax

        print("Yearly tax:", tax)
        print("Net salary:", net_salary)

    else:
        print("Invalid selection")
