# Week 05 – Tutorial 4 (Menu using letters)

import random

while True:
    print("\n=== WEEK 05 TUTORIAL 4 ===")
    print("a. Grade calculator")
    print("b. Add two numbers")
    print("c. Menu selection")
    print("d. Random number guessing")
    print("e. Odd or even")
    print("q. Exit")

    choice = input("Choose an option (a–e or q): ").lower()

    # 4a
    if choice == "a":
        mark = int(input("Enter mark (0–100): "))
        if 0 <= mark <= 100:
            if mark > 74:
                print("Distinction")
            elif mark >= 60:
                print("Merit")
            elif mark >= 40:
                print("Pass")
            else:
                print("Fail")
        else:
            print("Invalid mark")

    # 4b
    elif choice == "b":
        n1 = input("Enter first number: ")
        n2 = input("Enter second number: ")

        if n1.isdigit() and n2.isdigit():
            total = int(n1) + int(n2)
            print("Total:", total)

            if total < 100:
                print("Total is less than 100")
            elif total > 100:
                print("Total is more than 100")
            else:
                print("Total is exactly 100")
        else:
            print("Invalid input")

    # 4c
    elif choice == "c":
        print("1. Add")
        print("2. Search")
        print("3. Update")
        print("4. Delete")

        option = input("Choose option 1–4: ")

        if option == "1":
            print("Added")
        elif option == "2":
            print("Searched")
        elif option == "3":
            print("Updated")
        elif option == "4":
            print("Deleted")
        else:
            print("Invalid option")

    # 4d
    elif choice == "d":
        while True:
            number = random.randint(1, 5)
            guess = input("Guess number (1–5): ")

            if not guess.isdigit():
                print("Invalid input")
                continue

            if int(guess) == number:
                print("Correct!")
            else:
                print("Wrong. Number was:", number, ". Program stopped.")
                break

    # 4e
    elif choice == "e":
        num = input("Enter number (0–100): ")

        if num.isdigit() and 0 <= int(num) <= 100:
            if int(num) % 2 == 0:
                print("Even number")
            else:
                print("Odd number")
        else:
            print("Invalid input")

    elif choice == "q":
        print("Program ended.")
        break

    else:
        print("Invalid selection.")
