# Week 05 Tutorial 2

col = "   regent college London   "

# a) Remove leading and trailing whitespaces and store as col2
col2 = col.strip()
print(col2)

# b) Convert col2 to lowercase
print(col2.lower())

# c) Convert col2 to title case
print(col2.title())

# d) Convert col2 to uppercase
print(col2.upper())

# e) Find the word "college"
print(col2.find("college"))

# f) Replace "college" with "university" in col2
print(col2.replace("college", "university"))

# g) Check if col2 contains only alphabetic characters (!spaces make it False!)
print(col2.isalpha())