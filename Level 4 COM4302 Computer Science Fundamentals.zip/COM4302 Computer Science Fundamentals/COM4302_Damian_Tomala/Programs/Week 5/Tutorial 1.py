
col = "Regent College London"

# a) index 0 to 6
print(col[0:7])

# b) index 0, 7 and 15 together
print(col[0] + col[7] + col[15])

# c) print "College"
print(col[7:14])

# d) print "gentle"
part1 = col[2:6]     # "gent"
part2 = col[10:12]   # "le"
print(part1 + part2)

# e) last 3 characters
print(col[-3:])

# f) "Regent London"
print(col[0:6] + " " + col[15:21])