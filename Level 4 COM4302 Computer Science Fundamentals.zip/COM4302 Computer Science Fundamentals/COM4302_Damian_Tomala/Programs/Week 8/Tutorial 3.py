import csv
import os

def read_int(prompt):
    while True:
        text = input(prompt).strip()
        try:
            return int(text)
        except ValueError:
            print("Enter a whole number.")

def read_float(prompt):
    while True:
        text = input(prompt).strip()
        try:
            return float(text)
        except ValueError:
            print("Enter a number.")

def read_yes_no(prompt):
    while True:
        ans = input(prompt).strip().lower()
        if ans == "yes" or ans == "no":
            return ans
        print("Type yes or no.")

def ensure_csv(filepath, header, rows):
    if not os.path.exists(filepath):
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(header)
            w.writerows(rows)

def load_csv(filepath):
    with open(filepath, "r", newline="", encoding="utf-8") as f:
        r = csv.reader(f)
        header = next(r, None)
        data = [row for row in r if row]
    return header, data

def save_csv(filepath, header, data):
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(data)

def print_table(title, header, data):
    print("\n" + title)
    print("=" * 70)
    print(" | ".join(header))
    print("=" * 70)
    for i, row in enumerate(data, start=1):
        print(str(i).rjust(2) + ". " + " | ".join(str(x) for x in row))
    print("=" * 70)

def choose_index(max_len, prompt):
    if max_len <= 0:
        return None
    while True:
        n = read_int(prompt)
        if 1 <= n <= max_len:
            return n - 1
        print("Choose a number from 1 to " + str(max_len) + ".")

def tutorial3a_weather_file():
    filepath = "days.csv"
    header = ["day", "temperature", "outlook"]
    sample = [
        ["Sunday", "6", "Cloudy"],
        ["Monday", "8", "Sunny"],
        ["Tuesday", "5", "Foggy"],
        ["Wednesday", "7", "Cloudy"],
        ["Thursday", "9", "Sunny"],
    ]
    ensure_csv(filepath, header, sample)

    h, data = load_csv(filepath)
    print_table("Weather data from CSV", h, data)

    print("\nAdd a new record")
    day = input("Day name: ").strip()
    temp = read_int("Temperature: ")
    outlook = input("Outlook: ").strip()
    data.append([day, str(temp), outlook])
    save_csv(filepath, h, data)

    h, data = load_csv(filepath)
    print_table("After adding a record", h, data)

    print("\nDelete a record")
    idx = choose_index(len(data), "Enter record number to delete: ")
    if idx is not None:
        deleted = data.pop(idx)
        print("Deleted: " + " | ".join(deleted))
        save_csv(filepath, h, data)

    h, data = load_csv(filepath)
    print_table("After deleting a record", h, data)

def tutorial3b_salary_file():
    filepath = "salary.csv"
    header = ["name", "hourly_rate", "weekly_hours"]
    sample = [
        ["Aisha", "12.5", "18"],
        ["Ben", "11", "22"],
        ["Chen", "14.25", "15"],
    ]
    ensure_csv(filepath, header, sample)

    h, data = load_csv(filepath)
    print_table("Salary data from CSV", h, data)

    print("\nWeekly gross salary per staff")
    total_gross = 0.0
    for row in data:
        name = row[0]
        rate = float(row[1])
        hours = float(row[2])
        gross = rate * hours
        total_gross += gross
        print(name.ljust(12) + "Gross salary: " + str(round(gross, 2)))
    print("Total gross salary for all staff: " + str(round(total_gross, 2)))

    print("\nAdd a new staff record")
    name = input("Staff name: ").strip()
    rate = read_float("Hourly rate: ")
    hours = read_float("Weekly hours: ")
    data.append([name, str(rate), str(hours)])
    save_csv(filepath, h, data)

    h, data = load_csv(filepath)
    print_table("After adding a record", h, data)

    total_gross = 0.0
    for row in data:
        total_gross += float(row[1]) * float(row[2])
    print("Total gross salary for all staff after adding: " + str(round(total_gross, 2)))

def tutorial3c_students_file():
    filepath = "students.csv"
    header = ["student", "date", "submitted", "words"]
    sample = [
        ["Mina", "01 Nov 2025", "yes", "1200"],
        ["Omar", "01 Nov 2025", "no", "0"],
        ["Priya", "01 Nov 2025", "yes", "980"],
        ["Sam", "01 Nov 2025", "no", "0"],
    ]
    ensure_csv(filepath, header, sample)

    h, data = load_csv(filepath)
    print_table("Student assignment data from CSV", h, data)

    print("\nAdd a new student record")
    student = input("Student name: ").strip()
    date = input("Date: ").strip()
    submitted = read_yes_no("Submitted yes or no: ")
    words = read_int("Number of words: ")
    data.append([student, date, submitted, str(words)])
    save_csv(filepath, h, data)

    h, data = load_csv(filepath)
    print_table("All students after adding", h, data)

    submitted_list = [row for row in data if row[2].strip().lower() == "yes"]
    not_submitted_list = [row for row in data if row[2].strip().lower() != "yes"]

    print_table("Students who submitted", h, submitted_list)
    print_table("Students who did not submit", h, not_submitted_list)

def tutorial3d_sales_file():
    filepath = "targetsales.csv"
    header = ["staff", "total_sales", "target_met"]
    sample = [
        ["Aisha", "4200", "yes"],
        ["Ben", "3100", "no"],
        ["Chen", "5050", "yes"],
        ["Dana", "2900", "no"],
    ]
    ensure_csv(filepath, header, sample)

    h, data = load_csv(filepath)
    print_table("Sales data from CSV", h, data)

    total_all = 0.0
    for row in data:
        total_all += float(row[1])
    print("\nTotal sales of all staff: " + str(round(total_all, 2)))

    met = [row for row in data if row[2].strip().lower() == "yes"]
    not_met = [row for row in data if row[2].strip().lower() != "yes"]

    total_met = 0.0
    for row in met:
        total_met += float(row[1])

    total_not_met = 0.0
    for row in not_met:
        total_not_met += float(row[1])

    print_table("Staff who met target", h, met)
    print("Total sales of staff who met target: " + str(round(total_met, 2)))

    print_table("Staff who did not meet target", h, not_met)
    print("Total sales of staff who did not meet target: " + str(round(total_not_met, 2)))

def main_menu():
    while True:
        print("\nWEEK 08 TUTORIAL 3 MENU")
        print("a Weather CSV add print delete")
        print("b Salary CSV gross per staff add total gross")
        print("c Students CSV display all add record submitted list not submitted list")
        print("d Sales CSV totals and target lists")
        print("e Exit")
        choice = input("Choose option: ").strip().lower()

        if choice == "a":
            tutorial3a_weather_file()
        elif choice == "b":
            tutorial3b_salary_file()
        elif choice == "c":
            tutorial3c_students_file()
        elif choice == "d":
            tutorial3d_sales_file()
        elif choice == "e":
            print("Program finished.")
            break
        else:
            print("Invalid option. Choose a to e.")

main_menu()
