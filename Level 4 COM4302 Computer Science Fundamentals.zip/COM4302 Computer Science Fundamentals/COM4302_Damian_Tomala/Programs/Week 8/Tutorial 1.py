
# WEEK 08 – TUTORIAL 1
# FULL PROGRAM WITH DETAILED COMMENTS ON ALMOST EVERY LINE


# -------- HELPER FUNCTIONS -------

# Function to display data in a formatted table
def print_rows(title, headers, rows):
    print("\n" + title)                  # Print table title
    print("-" * 60)                      # Print separator line
    print(" | ".join(headers))           # Print table headers
    print("-" * 60)                      # Separator
    for i, row in enumerate(rows, 1):    # Loop through rows with index
        print(f"{i}. " + " | ".join(str(x) for x in row))
    print("-" * 60)                      # End of table


# Function to safely read integer input
def read_int(prompt):
    while True:
        try:
            return int(input(prompt))    # Try to convert input to int
        except ValueError:
            print("Please enter a valid number.")


# Function to safely read float input
def read_float(prompt):
    while True:
        try:
            return float(input(prompt))  # Convert input to float
        except ValueError:
            print("Please enter a valid number.")


# Function to read yes/no input only
def read_yes_no(prompt):
    while True:
        value = input(prompt).strip().lower()
        if value in ["yes", "no"]:
            return value
        print("Please type yes or no.")



# TUTORIAL 1A – WEATHER SYSTEM


def tutorial1a():
    # List containing weather data
    weather = [
        ["Sunday", 12, "Sunny"],
        ["Monday", 10, "Cloudy"],
        ["Tuesday", 7, "Rainy"],
        ["Wednesday", 9, "Windy"],
        ["Thursday", 11, "Sunny"],
        ["Friday", 6, "Foggy"],
        ["Saturday", 8, "Partly Cloudy"]
    ]

    # Display weather data
    print_rows("Weather Data", ["Day", "Temperature", "Outlook"], weather)

    # Add a new weather record
    print("\nAdd new weather record")
    day = input("Day: ")
    temp = read_int("Temperature: ")
    outlook = input("Outlook: ")
    weather.append([day, temp, outlook])

    # Display updated data
    print_rows("After adding record", ["Day", "Temperature", "Outlook"], weather)

    # Remove selected record
    index = read_int("Delete record number: ") - 1
    if 0 <= index < len(weather):
        weather.pop(index)

    # Display after deletion
    print_rows("After deleting record", ["Day", "Temperature", "Outlook"], weather)



# TUTORIAL 1B – SALARY SYSTEM


def tutorial1b():
    # Staff data: name, hourly rate, weekly hours
    staff = [
        ["Karina", 30.0, 18],
        ["Ben", 11.0, 22],
        ["Chen", 14.25, 15]
    ]

    # Show staff list
    print_rows("Staff salary data", ["Name", "Hourly rate", "Weekly hours"], staff)

    # Calculate salary for each employee
    total = 0
    for name, rate, hours in staff:
        gross = rate * hours
        total += gross
        print(f"{name} gross salary = {gross}")

    print(f"Total gross salary: {total}")

    # Add a new employee
    print("\nAdd new staff member")
    name = input("Name: ")
    rate = read_float("Hourly rate: ")
    hours = read_float("Weekly hours: ")
    staff.append([name, rate, hours])

    # Show updated staff list
    print_rows("Updated staff list", ["Name", "Rate", "Hours"], staff)



# TUTORIAL 1C – ASSIGNMENT TRACKING


def tutorial1c():
    # List storing student assignments
    assignments = [
        ["Mina", "2025-11-01", "yes", 1200],
        ["Omar", "2025-11-01", "no", 0],
        ["Priya", "2025-11-01", "yes", 980]
    ]

    # Show assignments
    print_rows("Assignments", ["Student", "Date", "Submitted", "Words"], assignments)

    # Add new assignment
    print("\nAdd new assignment")
    student = input("Student name: ")
    date = input("Date: ")
    submitted = read_yes_no("Submitted (yes/no): ")
    words = read_int("Word count: ")

    assignments.append([student, date, submitted, words])

    # Display updated assignments
    print_rows("All assignments", ["Student", "Date", "Submitted", "Words"], assignments)

    # Display submitted assignments
    print("\nSubmitted assignments:")
    print_rows("Submitted", ["Student", "Date", "Submitted", "Words"],
               [a for a in assignments if a[2] == "yes"])

    # Display not submitted assignments
    print("\nNot submitted:")
    print_rows("Not submitted", ["Student", "Date", "Submitted", "Words"],
               [a for a in assignments if a[2] == "no"])



# TUTORIAL 1D – SALES TRACKING


def tutorial1d():
    # Sales data
    sales = [
        ["Karina", 4200, "yes"],
        ["Ben", 3100, "no"],
        ["Chen", 5050, "yes"],
        ["Daria", 2900, "no"]
    ]

    # Display all sales
    print_rows("Sales data", ["Staff", "Total Sales", "Target Met"], sales)

    # Calculate total sales
    total_sales = sum(s[1] for s in sales)
    print("Total sales:", total_sales)

    # Separate staff by target achievement
    met = [s for s in sales if s[2] == "yes"]
    not_met = [s for s in sales if s[2] == "no"]

    # Display results
    print_rows("Met target", ["Staff", "Total Sales", "Target Met"], met)
    print("Total met:", sum(s[1] for s in met))

    print_rows("Not met target", ["Staff", "Total Sales", "Target Met"], not_met)
    print("Total not met:", sum(s[1] for s in not_met))


# =========================================================
# MAIN MENU
# =========================================================

def main():
    while True:
        print("\nWEEK 08 – MAIN MENU")
        print("1. Tutorial 1A – Weather")
        print("2. Tutorial 1B – Salary")
        print("3. Tutorial 1C – Assignments")
        print("4. Tutorial 1D – Sales")
        print("5. Exit")

        choice = input("Choose option: ")

        if choice == "1":
            tutorial1a()
        elif choice == "2":
            tutorial1b()
        elif choice == "3":
            tutorial1c()
        elif choice == "4":
            tutorial1d()
        elif choice == "5":            print("Program finished.")
            break
        else:
            print("Invalid option. Try again.")


main()
