# Week 08 Tutorial 2

# Multidimensional dictionary programs A to D
# One file with a start menu to choose which part to run


# INPUT FUNCTIONS

def read_int(prompt):
    while True:
        try:
            return int(input(prompt).strip())
        except ValueError:
            print("Enter a whole number.")

def read_float(prompt):
    while True:
        try:
            return float(input(prompt).strip())
        except ValueError:
            print("Enter a number.")

def read_yes_no(prompt):
    while True:
        ans = input(prompt).strip().lower()
        if ans in ["yes", "no"]:
            return ans
        print("Type yes or no.")


# PRINTING FUNCTIONS

def print_line():
    print("=" * 70)

def show_table(title, headers, rows):
    print("\n" + title)
    print_line()
    print(" | ".join(headers))
    print_line()
    for row in rows:
        print(" | ".join(str(x) for x in row))
    print_line()


# TUTORIAL 2A


def tutorial2a_weather_dict():
    weather = {
        "Sunday": {"temp": 18, "outlook": "Sunny"},
        "Monday": {"temp": 16, "outlook": "Partly Cloudy"},
        "Tuesday": {"temp": 14, "outlook": "Rainy"},
        "Wednesday": {"temp": 17, "outlook": "Cloudy"},
        "Thursday": {"temp": 19, "outlook": "Sunny"},
        "Friday": {"temp": 15, "outlook": "Windy"},
        "Saturday": {"temp": 20, "outlook": "Sunny"},
    }

    rows = [[day, info["temp"], info["outlook"]] for day, info in weather.items()]
    show_table("Tutorial 2A Weather data initial", ["Day", "Temperature", "Outlook"], rows)

    print("\nAdd a new weather record")
    day = input("Day name: ").strip()
    temp = read_int("Temperature: ")
    outlook = input("Outlook: ").strip()
    weather[day] = {"temp": temp, "outlook": outlook}

    rows = [[d, info["temp"], info["outlook"]] for d, info in weather.items()]
    show_table("Tutorial 2A Weather data after adding", ["Day", "Temperature", "Outlook"], rows)

    print("\nDelete a weather record")
    delete_day = input("Type day name to delete: ").strip()
    if delete_day in weather:
        deleted = weather.pop(delete_day)
        print("Deleted:", delete_day, deleted)
    else:
        print("Day not found.")

    rows = [[d, info["temp"], info["outlook"]] for d, info in weather.items()]
    show_table("Tutorial 2A Weather data after deleting", ["Day", "Temperature", "Outlook"], rows)


# TUTORIAL 2B


def tutorial2b_salary_dict():
    staff = {
        "Karina": {"rate": 30.00, "hours": 18},
        "Ben": {"rate": 11.00, "hours": 22},
        "Chen": {"rate": 14.25, "hours": 15},
        "Anna": {"rate": 16.50, "hours": 20},
        "Mark": {"rate": 12.00, "hours": 25},
        "Julia": {"rate": 18.00, "hours": 17},
        "Tom": {"rate": 10.50, "hours": 30},
        "Emma": {"rate": 19.00, "hours": 16},
        "Lucas": {"rate": 13.50, "hours": 21},
        "Sophie": {"rate": 15.00, "hours": 19},
    }

    rows = [[name, info["rate"], info["hours"]] for name, info in staff.items()]
    show_table("Tutorial 2B Staff data initial", ["Name", "Hourly rate", "Weekly hours"], rows)

    print("\nWeekly gross salary per staff")
    total_gross = 0.0
    for name, info in staff.items():
        gross = info["rate"] * info["hours"]
        total_gross += gross
        print(name, "Gross salary:", round(gross, 2))
    print("Total gross salary for all staff:", round(total_gross, 2))

    print("\nAdd a new staff record")
    name = input("Staff name: ").strip()
    rate = read_float("Hourly rate: ")
    hours = read_float("Weekly hours: ")
    staff[name] = {"rate": rate, "hours": hours}

    rows = [[n, info["rate"], info["hours"]] for n, info in staff.items()]
    show_table("Tutorial 2B Staff data after adding", ["Name", "Hourly rate", "Weekly hours"], rows)

    total_gross_after = 0.0
    for info in staff.values():
        total_gross_after += info["rate"] * info["hours"]
    print("Total gross salary for all staff after adding:", round(total_gross_after, 2))


# TUTORIAL 2C


def tutorial2c_assignments_dict():
    assignments = {
        "Anna": {"date": "2025-11-01", "submitted": "yes", "words": 1200},
        "Ben": {"date": "2025-11-01", "submitted": "no", "words": 0},
        "Chris": {"date": "2025-11-01", "submitted": "yes", "words": 980},
        "Diana": {"date": "2025-11-01", "submitted": "yes", "words": 1100},
        "Ethan": {"date": "2025-11-01", "submitted": "no", "words": 0},
        "Fiona": {"date": "2025-11-01", "submitted": "yes", "words": 1040},
        "George": {"date": "2025-11-01", "submitted": "no", "words": 0},
        "Hannah": {"date": "2025-11-01", "submitted": "yes", "words": 990},
        "Ivan": {"date": "2025-11-01", "submitted": "no", "words": 0},
        "Julia": {"date": "2025-11-01", "submitted": "yes", "words": 1300},
    }

    rows = [[s, info["date"], info["submitted"], info["words"]] for s, info in assignments.items()]
    show_table("Tutorial 2C Assignment tracking initial", ["Student", "Date", "Submitted", "Words"], rows)

    print("\nEnter a new assignment record")
    student = input("Student name: ").strip()
    date_str = input("Date (YYYY-MM-DD): ").strip()
    submitted = read_yes_no("Submitted (yes or no): ")
    words = read_int("Number of words: ")
    assignments[student] = {"date": date_str, "submitted": submitted, "words": words}

    rows = [[s, info["date"], info["submitted"], info["words"]] for s, info in assignments.items()]
    show_table("Tutorial 2C Assignment tracking after adding", ["Student", "Date", "Submitted", "Words"], rows)

    submitted_rows = []
    not_submitted_rows = []

    for s, info in assignments.items():
        if info["submitted"].lower() == "yes":
            submitted_rows.append([s, info["date"], info["submitted"], info["words"]])
        else:
            not_submitted_rows.append([s, info["date"], info["submitted"], info["words"]])

    show_table("Students who submitted", ["Student", "Date", "Submitted", "Words"], submitted_rows)
    show_table("Students who did not submit", ["Student", "Date", "Submitted", "Words"], not_submitted_rows)


# TUTORIAL 2D
# Output format updated to match your screenshot structure
# Data stays the same as your current program


def tutorial2d_sales_dict():
    sales = {
        "Karina": {"sales": 4200, "met": "yes"},
        "Ben": {"sales": 3100, "met": "no"},
        "Chen": {"sales": 5050, "met": "yes"},
        "Daria": {"sales": 2900, "met": "no"},
        "Emily": {"sales": 4600, "met": "yes"},
        "Frank": {"sales": 2700, "met": "no"},
        "George": {"sales": 3900, "met": "yes"},
        "Hannah": {"sales": 4100, "met": "yes"},
        "Ian": {"sales": 2800, "met": "no"},
        "Julia": {"sales": 4500, "met": "yes"},
    }

    staff_list = []

    for name, info in sales.items():
        target_text = "Yes" if info["met"].strip().lower() == "yes" else "No"
        staff_list.append({"name": name, "sales": info["sales"], "target": target_text})

    for i, item in enumerate(staff_list, 1):
        print(i, item)

    total_all = 0
    total_met = 0
    total_not_met = 0

    for item in staff_list:
        total_all += item["sales"]
        if item["target"] == "Yes":
            total_met += item["sales"]
        else:
            total_not_met += item["sales"]

    print("Total sales of all staff:", total_all)
    print("Total sales of all staff who met the target:", total_met)
    print("Total sales of all staff who did not meet target:", total_not_met)

    print("Staff's sales information who met the targets:")
    for i, item in enumerate(staff_list, 1):
        if item["target"] == "Yes":
            print(i, item["name"], item["sales"], item["target"])

    print("Staff's sales information who did not meet the targets:")
    for i, item in enumerate(staff_list, 1):
        if item["target"] == "No":
            print(i, item["name"], item["sales"], item["target"])


# MAIN MENU


def main_menu():
    while True:
        print("\nWEEK 08 TUTORIAL 2 MENU")
        print("A Weather dictionary add print delete")
        print("B Salary dictionary gross per staff add total gross")
        print("C Assignment dictionary add submitted list not submitted list")
        print("D Sales dictionary totals target met lists and totals")
        print("E Exit")

        choice = input("Choose option: ").strip().lower()

        if choice == "a":
            tutorial2a_weather_dict()
        elif choice == "b":
            tutorial2b_salary_dict()
        elif choice == "c":
            tutorial2c_assignments_dict()
        elif choice == "d":
            tutorial2d_sales_dict()
        elif choice == "e":
            print("Program finished.")
            break
        else:
            print("Invalid option. Choose A B C D or E.")

main_menu()
