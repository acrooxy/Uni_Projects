"""
COM4302 Part 2 Python Salary Calculation Application

Key rules from brief
1) Menu interface
2) Store staff records
3) Input staff name and salary or hourly rate
4) Tax: 20 percent applied only to income above 12570
5) National Insurance: fixed deduction (constant in this program)
6) Display payslip: gross pay, deductions, net pay
7) Additional features: search, delete, salary comparison
8) Code structured, commented, and suitable for testing

Note
The brief says "fixed NI" but does not specify the exact amount.
This program uses a constant NI_FIXED_ANNUAL. Change it if your tutor specifies a value.
"""

PERSONAL_ALLOWANCE = 12570.0
TAX_RATE = 0.20
NI_FIXED_ANNUAL = 500.0  # fixed annual National Insurance deduction for this coursework


def money(value: float) -> str:
    return f"£{value:,.2f}"


def read_non_empty(prompt: str) -> str:
    while True:
        s = input(prompt).strip()
        if s:
            return s
        print("Input cannot be empty.")


def read_float_positive(prompt: str) -> float:
    while True:
        s = input(prompt).strip()
        try:
            value = float(s)
            if value <= 0:
                print("Value must be greater than 0.")
                continue
            return value
        except ValueError:
            print("Please enter a valid number.")


def read_int_choice(prompt: str, min_value: int, max_value: int) -> int:
    while True:
        s = input(prompt).strip()
        if not s.isdigit():
            print("Please enter a valid option number.")
            continue
        v = int(s)
        if v < min_value or v > max_value:
            print("Option out of range.")
            continue
        return v


def calc_tax(gross: float) -> float:
    taxable = max(0.0, gross - PERSONAL_ALLOWANCE)
    return taxable * TAX_RATE


def calc_ni(gross: float) -> float:
    # fixed NI deduction as required by brief
    # for very low salaries you may cap at gross so net does not go negative
    return min(NI_FIXED_ANNUAL, gross)


def calc_net(gross: float) -> dict:
    tax = calc_tax(gross)
    ni = calc_ni(gross)
    deductions = tax + ni
    net = gross - deductions
    if net < 0:
        net = 0.0
    return {
        "gross": gross,
        "tax": tax,
        "ni": ni,
        "deductions": deductions,
        "net": net,
    }


def print_payslip(name: str, breakdown: dict) -> None:
    print()
    print("Payslip")
    print(f"Name: {name}")
    print(f"Gross pay: {money(breakdown['gross'])}")
    print(f"Income tax: {money(breakdown['tax'])}")
    print(f"National Insurance: {money(breakdown['ni'])}")
    print(f"Total deductions: {money(breakdown['deductions'])}")
    print(f"Net pay: {money(breakdown['net'])}")
    print()


def add_staff(staff: list) -> None:
    print()
    print("Add staff")
    name = read_non_empty("Enter staff name: ")

    print("Select pay input type")
    print("1 Annual salary")
    print("2 Hourly rate with weekly hours")
    choice = read_int_choice("Choose 1 or 2: ", 1, 2)

    if choice == 1:
        annual_salary = read_float_positive("Enter annual salary: ")
        gross = annual_salary
    else:
        hourly = read_float_positive("Enter hourly rate: ")
        hours = read_float_positive("Enter hours per week: ")
        gross = hourly * hours * 52.0

    staff.append({"name": name, "gross": gross})
    print(f"Saved: {name} with annual gross {money(gross)}")
    print()


def list_staff(staff: list) -> None:
    print()
    print("Staff list")
    if not staff:
        print("No staff records.")
        print()
        return

    for idx, s in enumerate(staff, start=1):
        b = calc_net(s["gross"])
        print(f"{idx}. {s['name']}  Gross {money(b['gross'])}  Net {money(b['net'])}")
    print()


def find_staff_indices(staff: list, query: str) -> list:
    q = query.strip().lower()
    matches = []
    for i, s in enumerate(staff):
        if q in s["name"].lower():
            matches.append(i)
    return matches


def search_staff(staff: list) -> None:
    print()
    print("Search staff")
    if not staff:
        print("No staff records.")
        print()
        return

    query = read_non_empty("Enter name to search: ")
    matches = find_staff_indices(staff, query)

    if not matches:
        print("No matches found.")
        print()
        return

    print("Matches")
    for k, i in enumerate(matches, start=1):
        s = staff[i]
        b = calc_net(s["gross"])
        print(f"{k}. {s['name']}  Gross {money(b['gross'])}  Net {money(b['net'])}")
    print()


def delete_staff(staff: list) -> None:
    print()
    print("Delete staff")
    if not staff:
        print("No staff records.")
        print()
        return

    list_staff(staff)
    choice = read_int_choice("Enter staff number to delete: ", 1, len(staff))
    removed = staff.pop(choice - 1)
    print(f"Deleted: {removed['name']}")
    print()


def calculate_payslip_for_staff(staff: list) -> None:
    print()
    print("Calculate payslip")
    if not staff:
        print("No staff records. Add staff first.")
        print()
        return

    list_staff(staff)
    choice = read_int_choice("Enter staff number for payslip: ", 1, len(staff))
    s = staff[choice - 1]
    b = calc_net(s["gross"])
    print_payslip(s["name"], b)


def compare_salaries() -> None:
    print()
    print("Compare two salaries")
    s1 = read_float_positive("Enter first annual salary: ")
    s2 = read_float_positive("Enter second annual salary: ")

    b1 = calc_net(s1)
    b2 = calc_net(s2)

    print()
    print("Comparison")
    print(f"Salary 1 Gross {money(b1['gross'])}  Net {money(b1['net'])}")
    print(f"Salary 2 Gross {money(b2['gross'])}  Net {money(b2['net'])}")

    if b1["net"] > b2["net"]:
        print("Result: Salary 1 produces a higher net pay.")
    elif b2["net"] > b1["net"]:
        print("Result: Salary 2 produces a higher net pay.")
    else:
        print("Result: Both salaries produce the same net pay.")
    print()


def show_rules() -> None:
    print()
    print("Calculation rules used in this program")
    print(f"Personal allowance: {money(PERSONAL_ALLOWANCE)}")
    print(f"Tax rate: {int(TAX_RATE * 100)} percent on income above personal allowance")
    print(f"National Insurance: fixed annual deduction of {money(NI_FIXED_ANNUAL)}")
    print()


def main() -> None:
    staff = []

    while True:
        print("Menu")
        print("1 Add staff")
        print("2 View staff list")
        print("3 Search staff")
        print("4 Delete staff")
        print("5 Calculate payslip")
        print("6 Compare two salaries")
        print("7 Show calculation rules")
        print("8 Exit")

        choice = read_int_choice("Choose an option: ", 1, 8)

        if choice == 1:
            add_staff(staff)
        elif choice == 2:
            list_staff(staff)
        elif choice == 3:
            search_staff(staff)
        elif choice == 4:
            delete_staff(staff)
        elif choice == 5:
            calculate_payslip_for_staff(staff)
        elif choice == 6:
            compare_salaries()
        elif choice == 7:
            show_rules()
        else:
            print()
            print("Goodbye.")
            break


if __name__ == "__main__":
    main()
